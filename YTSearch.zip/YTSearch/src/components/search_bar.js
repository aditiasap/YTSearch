import React, { Component } from 'react';

class SearchBar extends Component {
	constructor(props) {
		// Calling super(). To define methods that already defined on the parent class, in this case, Component (as parent) has its own constructor method
		super(props);
		
		// Initialize state
		this.state = { term: '' };
	}
	
	render() {
		return (
			<div className="search-bar">
				<input
					value={this.state.term}
					onChange={event => this.onInputChange(event.target.value) } />
			</div>
		);
	}
	
	onInputChange(term) {
		this.setState({ term });
		this.props.onSearchTermChange(term);
	}
}

export default SearchBar;